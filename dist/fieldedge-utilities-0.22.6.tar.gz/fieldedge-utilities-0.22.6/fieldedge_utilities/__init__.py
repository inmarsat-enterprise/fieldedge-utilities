"""
.. include:: ../README.md
"""
__docformat__ = 'google'
