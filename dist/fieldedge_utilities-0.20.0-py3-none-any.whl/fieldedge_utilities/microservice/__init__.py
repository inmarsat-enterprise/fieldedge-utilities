"""
.. include:: ../../docs/overviews/microservice.md
"""