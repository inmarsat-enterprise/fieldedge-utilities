"""
# FieldEdge Utilities

This Python library contains common functionality used by many of the Inmarsat
**FieldEdge** embedded microservices.

"""
__docformat__ = 'google'

__version__ = '0.1.2'