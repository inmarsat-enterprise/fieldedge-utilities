"""Helper functions for converting tags between PEP and JSON styles.

DEPRECATED - merged into `property` module.

Also provides a function for comparing object attributes for equivalence.

"""

from .property import *
