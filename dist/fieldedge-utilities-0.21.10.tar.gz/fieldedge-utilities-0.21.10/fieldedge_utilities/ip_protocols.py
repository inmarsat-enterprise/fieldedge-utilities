"""Enumerated types for protocol analysis.

*DEPRECATED*.
Moved to ip.protocols

"""
from fieldedge_utilities.ip.protocols import KnownTcpPorts, KnownUdpPorts

__all__ = ['KnownTcpPorts', 'KnownUdpPorts']
